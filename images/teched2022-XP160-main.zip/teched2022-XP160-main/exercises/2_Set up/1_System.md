<p ="text-align: left;"><strong>Prerequisites</strong><br /><br />The following requirements have to be met:&nbsp;</p>
<ul>
<li>SAP BTP trial account with entitlements for:
<ul>
<li><strong>SAP Business Application Studio</strong></li>
<li><strong>SAP Launchpad Service</strong><br /><br /></li>
</ul>
</li>
<li>SAP BTP <strong>account administrator</strong> privilege.</li>
</ul>
<p>SAP BTP Trial Accounts already have preconfigured a Cloud Foundry runtime environment and an SAP Business Application Studio development environment.</p>
<p>You start with creating the SAP BTP trial account and setting up the SAP Launchpad Services on the next project board cards.</p>
<p><strong>Skip the next Card in case you already have an SAP BTP Trial account!</strong></p>
